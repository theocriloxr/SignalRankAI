from __future__ import annotations

import asyncio
import logging
import os
import time as _time
import time
from typing import Iterable

import yfinance as yf

from data.fetcher import async_get_candles, get_asset_type, _get_last_provider_used
from db.market_cache import get_recent_candles
from db.session import get_session
import requests
import pandas as pd
from core.redis_state import state
import httpx
from data.alternative_providers import fetch_onchain_context

logger = logging.getLogger(__name__)

_YF_COOLDOWN_UNTIL = 0.0
_YF_NO_CANDLE_LAST_LOG: dict[tuple[str, str], float] = {}


def usable_timeframe_payloads(market_data: dict, minimum_candles: int | None = None) -> dict:
    """Return only timeframe payloads containing normalized, usable OHLCV candles."""
    minimum = max(1, int(minimum_candles or _env_int("MARKET_CACHE_MIN_CANDLES", 20)))
    usable: dict = {}
    for timeframe, payload in (market_data or {}).items():
        if str(timeframe).startswith("_") or not isinstance(payload, dict):
            continue
        candles = payload.get("candles")
        if not isinstance(candles, list) or len(candles) < minimum:
            continue
        normalized = _sanitize_ohlcv(candles)
        if len(normalized) < minimum or not _validate_ohlcv(normalized):
            continue
        payload["candles"] = normalized
        usable[str(timeframe)] = payload
    return usable


CRYPTO_REQUIRED_TIMEFRAMES = ("5m", "15m", "1h")


def market_data_usability(asset: str, requested: Iterable[str], market_data: dict) -> dict:
    """Describe whether an asset has enough data to enter the strategy pipeline.

    Crypto strategies require 5m/15m/1h. Other requested crypto timeframes are
    enrichment only and therefore cannot make an otherwise usable asset fail.
    Existing multi-asset behavior remains permissive: one usable timeframe is
    sufficient for non-crypto assets.
    """
    requested_tfs = [str(tf).strip().lower() for tf in (requested or []) if str(tf).strip()]
    usable = usable_timeframe_payloads(market_data)
    asset_class = str(get_asset_type(asset) or "unknown").lower().strip()
    required_tfs = list(CRYPTO_REQUIRED_TIMEFRAMES) if asset_class == "crypto" else []
    optional_tfs = [tf for tf in requested_tfs if tf not in required_tfs]
    required_status = {tf: tf in usable for tf in required_tfs}
    optional_status = {tf: tf in usable for tf in optional_tfs}
    provider_by_timeframe: dict[str, str] = {}
    for tf in requested_tfs:
        payload = (market_data or {}).get(tf)
        source = payload.get("source") if isinstance(payload, dict) else None
        provider_by_timeframe[tf] = str(source or _get_last_provider_used(asset, tf) or "missing")

    if required_tfs:
        missing_required = [tf for tf, ok in required_status.items() if not ok]
        is_usable = not missing_required
        final_reason = (
            "usable_required_timeframes"
            if is_usable
            else f"missing_required_timeframe:{missing_required[0]}"
        )
    else:
        is_usable = bool(usable)
        final_reason = "usable_timeframe_available" if is_usable else "no_usable_timeframes"

    return {
        "asset": str(asset),
        "asset_class": asset_class,
        "required_timeframes": required_status,
        "optional_timeframes": optional_status,
        "provider_by_timeframe": provider_by_timeframe,
        "usable_timeframes": sorted(usable),
        "usable": bool(is_usable),
        "final_reason": final_reason,
    }


def count_usable_market_data_assets(all_market_data: dict, asset_to_timeframes: dict) -> int:
    """Count assets ready for strategies using the same contract as the engine."""
    return sum(
        1
        for asset, payload in (all_market_data or {}).items()
        if isinstance(payload, dict)
        and market_data_usability(
            asset,
            (asset_to_timeframes or {}).get(asset, []),
            payload,
        ).get("usable")
    )


def market_data_diagnostics(asset: str, requested: Iterable[str], market_data: dict) -> dict:
    minimum = max(1, _env_int("MARKET_CACHE_MIN_CANDLES", 20))
    usable = usable_timeframe_payloads(market_data, minimum)
    reasons: dict[str, str] = {}
    for timeframe in requested or []:
        payload = (market_data or {}).get(str(timeframe))
        if not isinstance(payload, dict):
            reasons[str(timeframe)] = "missing_payload"
            continue
        candles = payload.get("candles")
        if not isinstance(candles, list):
            reasons[str(timeframe)] = "candles_not_list"
        elif len(candles) < minimum:
            reasons[str(timeframe)] = f"insufficient_candles:{len(candles)}/{minimum}"
        elif str(timeframe) not in usable:
            reasons[str(timeframe)] = "invalid_ohlcv_schema"
    result = {
        "asset": str(asset),
        "usable_timeframes": sorted(usable),
        "rejected_timeframes": reasons,
        "minimum_candles": minimum,
    }
    result.update(market_data_usability(asset, requested, market_data))
    return result


def _yf_timeout_seconds() -> float:
    try:
        return float((os.getenv("YFINANCE_TIMEOUT_SECONDS") or "6").strip())
    except Exception:
        return 6.0


def _yf_cooldown_seconds() -> float:
    try:
        return float((os.getenv("YFINANCE_COOLDOWN_SECONDS") or "120").strip())
    except Exception:
        return 120.0


def _yf_available() -> bool:
    return time.time() >= float(_YF_COOLDOWN_UNTIL or 0.0)


def _should_log_yf_no_candles(symbol: str, timeframe: str) -> bool:
    try:
        cooldown = float(os.getenv("NO_CANDLE_LOG_COOLDOWN_SECONDS", "900") or 900)
    except Exception:
        cooldown = 900.0
    key = (str(symbol or "").upper().strip(), str(timeframe or "").lower().strip())
    now = time.time()
    last = float(_YF_NO_CANDLE_LAST_LOG.get(key) or 0.0)
    if now - last < max(60.0, cooldown):
        return False
    _YF_NO_CANDLE_LAST_LOG[key] = now
    return True


def _set_yf_cooldown(reason: str) -> None:
    global _YF_COOLDOWN_UNTIL
    _YF_COOLDOWN_UNTIL = time.time() + _yf_cooldown_seconds()
    logger.warning("[market_data] yfinance cooldown set: %s", reason)


async def _fetch_yfinance_with_timeout(asset: str, tf: str, limit: int) -> list:
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(_fetch_via_yfinance, asset, tf, limit),
            timeout=_yf_timeout_seconds(),
        )
    except asyncio.TimeoutError:
        _set_yf_cooldown("timeout")
        return []
    except Exception as exc:
        _set_yf_cooldown(str(exc))
        return []


async def _tradingview_indicators(asset: str, tf: str) -> dict:
    if not _env_bool("TRADINGVIEW_ENABLED", True):
        return {}
    try:
        from tradingview_ta import TA_Handler, Interval
    except Exception:
        return {}

    tf_map = {
        "1m": Interval.INTERVAL_1_MINUTE,
        "5m": Interval.INTERVAL_5_MINUTES,
        "15m": Interval.INTERVAL_15_MINUTES,
        "1h": Interval.INTERVAL_1_HOUR,
        "4h": Interval.INTERVAL_4_HOURS,
        "1d": Interval.INTERVAL_1_DAY,
    }
    tv_tf = tf_map.get(str(tf).lower().strip())
    if tv_tf is None:
        return {}

    try:
        asset_upper = str(asset or "").upper().strip()
        if asset_upper.endswith(("USDT", "BUSD", "USDC", "BTC", "ETH")):
            exchange = "BINANCE"
            screener = "crypto"
            symbol = asset_upper
        else:
            exchange = "FX_IDC"
            screener = "forex"
            symbol = asset_upper

        handler = TA_Handler(
            symbol=symbol,
            screener=screener,
            exchange=exchange,
            interval=tv_tf,
        )
        try:
            tv_timeout = max(0.5, float(os.getenv("TRADINGVIEW_ENRICHMENT_TIMEOUT_SECONDS", "2") or 2))
        except Exception:
            tv_timeout = 2.0
        analysis = await asyncio.wait_for(
            asyncio.to_thread(handler.get_analysis),
            timeout=tv_timeout,
        )
        indicators = getattr(analysis, "indicators", None)
        if isinstance(indicators, dict):
            return indicators
    except Exception:
        return {}
    return {}

# yfinance can emit noisy symbol-level errors during fallback; keep app logs readable.
try:
    logging.getLogger("yfinance").setLevel(logging.CRITICAL)
except Exception:
    pass


# ---------------------------------------------------------------------------
# Unified ticker formatter — maps canonical SignalRankAI symbols to each
# provider's required format. Use this instead of ad-hoc conversions.
# ---------------------------------------------------------------------------

_BINANCE_OVERRIDES: dict[str, str] = {
    "XAUUSD": "XAUUSDT",
    "BTCUSD": "BTCUSDT",
    "ETHUSD": "ETHUSDT",
}

_OANDA_OVERRIDES: dict[str, str] = {
    "XAUUSD": "XAU_USD",
    "XAGUSD": "XAG_USD",
    "BTCUSD": "BTC_USD",
    "ETHUSD": "ETH_USD",
}

_YFINANCE_OVERRIDES: dict[str, str] = {
    "XAUUSD": "GC=F",
    "XAGUSD": "SI=F",
    "WTIUSD": "CL=F",
    "CRUDEOIL": "CL=F",
    "NATGAS": "NG=F",
    "BTCUSD": "BTC-USD",
    "ETHUSD": "ETH-USD",
    "BNBUSD": "BNB-USD",
    "SOLUSD": "SOL-USD",
}

_METAAPI_OVERRIDES: dict[str, str] = {
    "XAUUSD": "XAUUSD",
    "BTCUSD": "BTCUSD",
    "ETHUSD": "ETHUSD",
}


def format_ticker(symbol: str, provider: str = "yfinance") -> str:
    """Convert a canonical SignalRankAI symbol to the format required by a given provider.

    Args:
        symbol:   Canonical symbol, e.g. ``"BTCUSDT"``, ``"EURUSD"``, ``"XAUUSD"``.
        provider: One of ``"yfinance"``, ``"binance"``, ``"oanda"``, ``"metaapi"``,
                  ``"polygon"``, ``"twelvedata"``, ``"alphavantage"``.

    Returns:
        The provider-specific ticker string.

    Examples:
        >>> format_ticker("XAUUSD", "yfinance")
        'GC=F'
        >>> format_ticker("BTCUSDT", "binance")
        'BTCUSDT'
        >>> format_ticker("EURUSD", "oanda")
        'EUR_USD'
        >>> format_ticker("AAPL", "polygon")
        'AAPL'
    """
    if not symbol:
        return symbol
    s = str(symbol).upper().strip()
    p = str(provider).lower().strip()

    if p == "yfinance":
        if s in _YFINANCE_OVERRIDES:
            return _YFINANCE_OVERRIDES[s]
        # FX pairs like EURUSD must map to EURUSD=X (not EUR-USD).
        if len(s) == 6 and s[:3].isalpha() and s[3:].isalpha():
            return f"{s}=X"
        if s.endswith("USDT") and len(s) > 4:
            return f"{s[:-4]}-USD"
        if s.endswith("USD") and len(s) > 3 and s[:3].isalpha() and s[3:] == "USD":
            return f"{s[:-3]}-USD"
        return s

    if p == "binance":
        if s in _BINANCE_OVERRIDES:
            return _BINANCE_OVERRIDES[s]
        if s.endswith("-USD"):
            return s[:-4] + "USDT"
        return s

    if p == "oanda":
        if s in _OANDA_OVERRIDES:
            return _OANDA_OVERRIDES[s]
        if len(s) == 6 and s[:3].isalpha() and s[3:].isalpha():
            return f"{s[:3]}_{s[3:]}"
        return s

    if p == "metaapi":
        return _METAAPI_OVERRIDES.get(s, s)

    if p in ("polygon", "twelvedata", "alphavantage"):
        if s.endswith("USDT"):
            return s[:-1]  # BTCUSDT -> BTCUST  — callers apply their own suffix
        if len(s) == 6 and s[:3].isalpha() and s[3:].isalpha():
            return f"{s[:3]}/{s[3:]}"
        return s

    return s


# ---------------------------------------------------------------------------
# Async circuit-breaker waterfall for OHLCV fetching
# ---------------------------------------------------------------------------

async def fetch_candles_with_circuit_breaker(
    symbol: str,
    timeframe: str,
    limit: int = 200,
    timeout: float = 2.5,
) -> list:
    """Fetch OHLCV data with async circuit-breaker fallback chain.

    Priority:
        1. Binance REST (fastest for crypto; 3 s timeout)
        2. yfinance (universal; 3 s timeout)
        3. MetaApi live price only (price-only stub for non-zero return)

    Each provider is wrapped in ``asyncio.wait_for(..., timeout=2.5)`` so a
    hanging upstream never blocks the engine.
    """

    async def _try_binance() -> list:
        url = (
            f"https://api.binance.com/api/v3/klines"
            f"?symbol={format_ticker(symbol, 'binance')}"
            f"&interval={timeframe}&limit={min(limit, 1000)}"
        )
        import httpx
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            raw = resp.json()
            candles = []
            for k in raw:
                candles.append({
                    "timestamp": int(k[0]) // 1000,
                    "open": float(k[1]),
                    "high": float(k[2]),
                    "low": float(k[3]),
                    "close": float(k[4]),
                    "volume": float(k[5]),
                })
            return candles

    async def _try_yfinance() -> list:
        return await asyncio.wait_for(
            asyncio.to_thread(_fetch_via_yfinance, symbol, timeframe, limit),
            timeout=timeout,
        )

    # 1 — Binance (crypto only; skip for FX/commodities)
    if symbol.endswith("USDT") or symbol.endswith("BTC") or symbol.endswith("ETH"):
        try:
            candles = await asyncio.wait_for(_try_binance(), timeout=timeout)
            if candles:
                logger.debug(f"[circuit_breaker] Binance OK for {symbol} {timeframe}")
                return candles
        except (asyncio.TimeoutError, Exception) as exc:
            logger.warning(f"[circuit_breaker] Binance failed for {symbol}: {exc}; trying yfinance")

    # 2 — yfinance
    try:
        candles = await _try_yfinance()
        if candles:
            logger.debug(f"[circuit_breaker] yfinance OK for {symbol} {timeframe}")
            return candles
    except (asyncio.TimeoutError, Exception) as exc:
        logger.warning(f"[circuit_breaker] yfinance failed for {symbol}: {exc}")

    logger.error(f"[circuit_breaker] All providers failed for {symbol} {timeframe}")
    return []


# ---------------------------------------------------------------------------
# Order-block / FVG detection (appends is_near_order_block flag)
# ---------------------------------------------------------------------------

def detect_order_blocks(candles: list, lookback: int = 100) -> bool:
    """Scan the last ``lookback`` candles for Fair Value Gaps / Imbalances.

    An FVG exists when candle[i-2].high < candle[i].low (bullish) or
    candle[i-2].low > candle[i].high (bearish) — leaving an unfilled gap.

    Returns True if the current price (last close) sits within 0.5% of any FVG.
    """
    if not candles or len(candles) < 3:
        return False
    recent = candles[-lookback:] if len(candles) > lookback else candles
    try:
        current_price = float(recent[-1].get("close", 0))
        if current_price <= 0:
            return False
        for i in range(2, len(recent)):
            prev2_high = float(recent[i - 2].get("high", 0))
            prev2_low = float(recent[i - 2].get("low", 0))
            curr_low = float(recent[i].get("low", 0))
            curr_high = float(recent[i].get("high", 0))
            # Bullish FVG: gap between candle[i-2].high and candle[i].low
            if prev2_high < curr_low:
                mid = (prev2_high + curr_low) / 2
                if abs(current_price - mid) / current_price <= 0.005:
                    return True
            # Bearish FVG: gap between candle[i].high and candle[i-2].low
            if curr_high < prev2_low:
                mid = (curr_high + prev2_low) / 2
                if abs(current_price - mid) / current_price <= 0.005:
                    return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# Legacy shim — kept for callers that have not been updated yet
# ---------------------------------------------------------------------------

def _convert_to_yfinance_symbol(symbol: str) -> str:
    """Convert symbol to yfinance format using format_ticker.
    
    This is the primary conversion function. Note: For crypto symbols like AAVEUSDT,
    yfinance may not have data - the _fetch_via_yfinance function will try multiple formats as fallback.
    """
    return format_ticker(symbol, "yfinance")


def _get_yfinance_symbol_variants(symbol: str) -> list:
    """Generate multiple yfinance ticker variants to try.
    
    FIX: This is CRITICAL - different crypto symbols need different formats
    and yfinance is inconsistent. We try multiple formats to maximize success.
    
    Returns list of ticker strings in order of likelihood to work.
    """
    if not symbol:
        return [symbol]
    
    s = str(symbol).upper().strip()
    variants = []
    
    # For USDT pairs (crypto), try these formats
    if s.endswith("USDT"):
        base = s[:-4]  # e.g., AAVE from AAVEUSDT
        # Most likely to work (most common crypto tickers on yfinance)
        variants = [
            f"{base}-USD",      # AAVE-USD (most common format)
            f"{base}=X",       # AAVE=X 
            base,              # Just the base (AAVE) - sometimes works
            s,                 # Original (AAVEUSDT) - rarely works but try anyway
        ]
    # For BUSD pairs
    elif s.endswith("BUSD"):
        base = s[:-4]
        variants = [f"{base}-USD", f"{base}=X", base]
    # For USDT-like
    elif s.endswith("USDC"):
        base = s[:-4]
        variants = [f"{base}-USD", f"{base}=X", base]
    # For standard 6-char FX pairs like EURUSD
    elif len(s) == 6 and s[:3].isalpha() and s[3:].isalpha():
        variants = [f"{s[:3]}{s[3:]}X", f"{s[:3]}-{s[3:]}", s]
    else:
        # For everything else, start with format_ticker result then try original
        variants = [format_ticker(symbol, "yfinance"), s]
    
    # Dedupe while preserving order
    seen = set()
    unique_variants = []
    for v in variants:
        v_upper = v.upper().strip() if v else ""
        if v_upper and v_upper not in seen:
            seen.add(v_upper)
            unique_variants.append(v)
    
    return unique_variants


def _fetch_via_yfinance(symbol: str, timeframe: str, limit: int) -> list:
    """Fetch OHLCV data synchronously from yfinance and return list of candles.

    FIX: Now tries multiple ticker formats to handle yfinance's inconsistent behavior.
    This is the key fix for "No candles found" errors.
    
    Each candle is a dict with keys: open, high, low, close, volume, timestamp
    Timestamp is seconds since epoch.
    """
    # Map timeframe to yfinance interval
    interval_map = {
        "1m": "1m",
        "5m": "5m",
        "15m": "15m",
        "1h": "1h",
        "4h": "4h",
        "1d": "1d",
    }
    interval = interval_map.get(str(timeframe), "1h")
    
    # Get all ticker variants to try
    variants = _get_yfinance_symbol_variants(symbol)
    
    # Try each variant until we get data
    for yf_symbol in variants:
        if not yf_symbol:
            continue
            
        try:
            ticker = yf.Ticker(yf_symbol)
            
            # Request history
            df = ticker.history(period=None, interval=interval)
            if df is None or df.empty:
                # This variant didn't work, try next
                logger.debug(f"[yfinance] {yf_symbol} returned empty for {symbol}, trying next variant")
                continue

            # Ensure expected column names exist (case-insensitive)
            df_cols = {c.lower(): c for c in df.columns}
            out = []
            for idx, row in df.iterrows():
                try:
                    o = row[df_cols.get("open", "Open")]
                    h = row[df_cols.get("high", "High")]
                    l = row[df_cols.get("low", "Low")]
                    c = row[df_cols.get("close", "Close")]
                    v = row[df_cols.get("volume", "Volume")]
                except Exception:
                    # Skip rows we cannot parse
                    continue

                ts = None
                try:
                    # pandas.Timestamp -> seconds
                    if hasattr(idx, "timestamp"):
                        ts = int(idx.timestamp())
                    else:
                        ts = int(pd.to_datetime(idx).timestamp())
                except Exception:
                    ts = None

                out.append({
                    "open": float(o) if o is not None else 0.0,
                    "high": float(h) if h is not None else 0.0,
                    "low": float(l) if l is not None else 0.0,
                    "close": float(c) if c is not None else 0.0,
                    "volume": float(v) if v is not None else 0.0,
                    "timestamp": int(ts) if ts is not None else 0,
                })

            # If we got here and have data, return it
            if out:
                logger.info(f"[yfinance] success: {symbol} -> {yf_symbol} got {len(out)} candles")
                # Trim to requested limit if limit provided
                if limit and isinstance(limit, int) and len(out) > limit:
                    out = out[-limit:]
                return out
                
        except Exception as e:
            # This variant failed with exception, try next
            logger.debug(f"[yfinance] {yf_symbol} failed for {symbol}: {e}, trying next variant")
            continue
    
    # All variants failed
    if _should_log_yf_no_candles(symbol, timeframe):
        logger.warning(f"[yfinance] all variants exhausted for {symbol}, no candles found")
    return []


def get_realtime_price(symbol: str) -> float | None:
    """Get latest price from yfinance, fallback to Binance REST if needed."""
    try:
        yf_symbol = _convert_to_yfinance_symbol(symbol)
        ticker = yf.Ticker(yf_symbol)
        # Fast-info may contain lastPrice
        fi = getattr(ticker, "fast_info", None)
        if isinstance(fi, dict) and fi.get("lastPrice") is not None:
            return float(fi.get("lastPrice"))
        # Some versions expose last_price differently
        info = getattr(ticker, "info", None)
        if isinstance(info, dict) and info.get("regularMarketPrice") is not None:
            return float(info.get("regularMarketPrice"))
    except Exception:
        pass

    # Fallback to Binance public API for symbols like BTCUSDT
    try:
        resp = requests.get(f"https://api.binance.com/api/v3/ticker/price?symbol={symbol.upper()}")
        if resp.status_code == 200:
            data = resp.json()
            price = data.get("price")
            if price is not None:
                return float(price)
    except Exception:
        pass

    return None


def _env_int(name: str, default: int) -> int:
    try:
        return int((os.getenv(name) or str(default)).strip())
    except Exception:
        return int(default)


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return bool(default)
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


def _timeframe_to_seconds(tf: str) -> int:
    """Convert timeframe string to seconds."""
    mapping = {
        "1m": 60,
        "5m": 300,
        "15m": 900,
        "1h": 3600,
        "4h": 14400,
        "1d": 86400,
    }
    return mapping.get(tf, 3600)


def _validate_ohlcv(candles: list) -> bool:
    """Validate OHLCV data integrity.
    
    Returns True if all candles pass validation, False otherwise.
    """
    if not candles:
        return True
    
    # Allow tiny floating-point tolerance to avoid false negatives from providers.
    eps = 1e-6

    for i, c in enumerate(candles):
        try:
            o = float(c.get("open", 0))
            h = float(c.get("high", 0))
            l = float(c.get("low", 0))
            close = float(c.get("close", 0))
            
            # Validate high >= low (fundamental relationship)
            if h + eps < l:
                logger.warning(f"OHLCV validation failed at candle {i}: high={h} < low={l}")
                return False
            
            # Validate high >= max(open, close)
            if h + eps < max(o, close):
                logger.warning(f"OHLCV validation failed at candle {i}: high={h} < max(open={o}, close={close})")
                return False
            
            # Validate low <= min(open, close)
            if l - eps > min(o, close):
                logger.warning(f"OHLCV validation failed at candle {i}: low={l} > min(open={o}, close={close})")
                return False
        except (ValueError, TypeError) as e:
            logger.warning(f"OHLCV validation failed at candle {i}: {e}")
            return False
    
    # Validate candles are sorted by timestamp ascending
    timestamps = []
    for c in candles:
        ts = c.get("timestamp")
        if ts is not None:
            # Handle both ms and seconds
            ts_val = int(ts) if isinstance(ts, (int, float)) else 0
            if ts_val > 10**12:  # milliseconds
                ts_val = ts_val // 1000
            timestamps.append(ts_val)
    
    if timestamps and timestamps != sorted(timestamps):
        logger.warning("OHLCV validation failed: candles not sorted by timestamp ascending")
        return False
    
    return True


def _sanitize_ohlcv(candles: list) -> list:
    """Normalize candle OHLC values to prevent minor provider inconsistencies.

    Ensures: high >= max(open, close) and low <= min(open, close).
    Rows that cannot be parsed are dropped.
    """
    if not candles:
        return candles

    out: list = []
    for c in candles:
        try:
            o = float(c.get("open", 0))
            h = float(c.get("high", 0))
            l = float(c.get("low", 0))
            close = float(c.get("close", 0))

            h = max(h, o, close)
            l = min(l, o, close)

            nc = dict(c)
            nc["open"] = o
            nc["high"] = h
            nc["low"] = l
            nc["close"] = close
            if not nc.get("timestamp") and nc.get("time") is not None:
                raw_ts = nc.get("time")
                try:
                    if isinstance(raw_ts, (int, float)):
                        ts_val = int(float(raw_ts))
                        nc["timestamp"] = ts_val
                    else:
                        parsed = pd.to_datetime(str(raw_ts), utc=True, errors="coerce")
                        if not pd.isna(parsed):
                            nc["timestamp"] = int(float(parsed.timestamp()) * 1000)
                except Exception:
                    pass
            out.append(nc)
        except Exception:
            continue
    return out


def _check_staleness(candles: list, timeframe: str) -> tuple[bool, float]:
    """Check if cached candles are stale.
    
    Returns (is_fresh, data_age_seconds).
    Candles are stale if the latest candle is older than 2× the timeframe interval.
    """
    if not candles:
        return False, 0.0
    
    def _to_epoch_seconds(value) -> int | None:
        if value is None:
            return None
        try:
            if isinstance(value, (int, float)):
                ts_val = int(float(value))
                return ts_val // 1000 if ts_val > 10**12 else ts_val
            raw = str(value).strip()
            if not raw:
                return None
            if raw.replace(".", "", 1).isdigit():
                ts_val = int(float(raw))
                return ts_val // 1000 if ts_val > 10**12 else ts_val
            dt = pd.to_datetime(raw, utc=True, errors="coerce")
            if pd.isna(dt):
                return None
            return int(dt.timestamp())
        except Exception:
            return None

    # Get the latest candle's timestamp
    latest_candle = candles[-1]
    ts = latest_candle.get("timestamp")
    
    if ts is None:
        logger.warning(f"Staleness check failed for {timeframe}: no timestamp in latest candle")
        return False, 0.0
    
    # Convert timestamp to seconds
    try:
        ts_val = _to_epoch_seconds(ts)
        if ts_val is None or ts_val <= 0:
            raise ValueError(f"invalid timestamp: {ts!r}")
        
        current_time = time.time()
        data_age = current_time - ts_val
        
        # Calculate staleness threshold (2× timeframe interval)
        tf_seconds = _timeframe_to_seconds(timeframe)
        threshold = 2 * tf_seconds
        
        is_fresh = data_age <= threshold
        
        if not is_fresh:
            logger.warning(
                f"Staleness check failed for {timeframe}: "
                f"data age={data_age:.0f}s exceeds threshold={threshold}s (2×{tf_seconds}s)"
            )
        
        return is_fresh, data_age
    except (ValueError, TypeError) as e:
        logger.warning(f"Staleness check failed for {timeframe}: {e}")
        return False, 0.0


async def fetch_market_data_cached(asset: str, timeframes: Iterable[str]) -> dict:
    """Fetch market data from yfinance first, then Postgres cache, then fallback to REST.

    Priority order:
    1. yfinance (primary source for all assets)
    2. Postgres cache (from WS ingestor)
    3. REST providers (Binance/Bybit/etc)

    FIX: Lowered default minimum candles from 80 to 20 to prevent signal starvation
    when providers return limited data. In degraded mode, accepts 5+ candles.
    """

    tfs = [str(tf).strip() for tf in (timeframes or []) if str(tf).strip()]
    if not tfs:
        return {}

    # FIX: Lowered from 80 to 20 to allow more signals through when providers return limited data
    want = _env_int("MARKET_CACHE_MIN_CANDLES", 20)
    limit = _env_int("MARKET_CACHE_READ_LIMIT", 200)
    use_cache = _env_bool("MARKET_CACHE_ENABLED", True)
    use_yfinance = _env_bool("YFINANCE_ENABLED", True)
    is_crypto_asset = str(get_asset_type(asset) or "").lower() == "crypto"
    if is_crypto_asset and not _env_bool("YFINANCE_CRYPTO_PRIMARY_ENABLED", False):
        use_yfinance = False

    out: dict = {}
    
    # 1. Try yfinance first (primary source)
    if use_yfinance and _yf_available():
        async def _fetch_yf(tf: str):
            try:
                yf_candles = await _fetch_yfinance_with_timeout(asset, tf, limit)
                if yf_candles and len(yf_candles) >= want:
                    yf_candles = _sanitize_ohlcv(yf_candles)
                    # Add data age calculation
                    if yf_candles:
                        latest_ts = _check_staleness(yf_candles, tf)[1]
                        data_age = int(latest_ts) if latest_ts and latest_ts > 0 else None
                    else:
                        data_age = None
                    
                    return tf, {
                        "candles": yf_candles,
                        "source": "yfinance",
                        "data_age_seconds": data_age
                    }
                else:
                    # FIX: Add QUALITY_GATE logging for visibility into data rejection reasons
                    got_candles = len(yf_candles) if yf_candles else 0
                    reason = f"need_{want}" if got_candles > 0 else "no_data"
                    logger.warning(
                        f"[QUALITY_GATE] {asset} {tf} candles={got_candles} valid=False reason={reason}"
                    )
                    logger.warning(f"yfinance failed/insufficient for {asset} {tf}, falling back to cache/REST")
            except Exception as e:
                logger.warning(f"yfinance exception for {asset} {tf}: {e}")
            return tf, {}

        yf_results = await asyncio.gather(*[_fetch_yf(tf) for tf in tfs])
        for tf, payload in yf_results:
            if payload:
                out[tf] = payload
                logger.info(
                    "[market_data] yfinance success for %s %s: %s candles",
                    asset,
                    tf,
                    len(payload.get("candles") or []),
                )
    elif use_yfinance and not _yf_available():
        logger.warning("[market_data] yfinance skipped due to cooldown")

    # 2. Try cache for missing non-crypto timeframes. Crypto intentionally
    # attempts live exchange providers first; cache is its final fallback.
    missing_after_yf = [tf for tf in tfs if tf not in out]
    if use_cache and missing_after_yf and not is_crypto_asset:
        try:
            async with get_session() as session:
                for tf in missing_after_yf:
                    candles = await get_recent_candles(session, symbol=asset, timeframe=tf, limit=limit)
                    if candles:
                        logger.info(f"[market_data] asset={asset} tf={tf} candles_fetched={len(candles)}")
                    
                    if candles and len(candles) >= want:
                        candles = _sanitize_ohlcv(candles)
                        # Validate OHLCV
                        if not _validate_ohlcv(candles):
                            logger.warning(f"Cached candles for {asset} {tf} failed OHLCV validation, skipping cache")
                            continue
                        
                        # Check staleness
                        is_fresh, data_age = _check_staleness(candles, tf)
                        if not is_fresh:
                            logger.warning(f"Cached candles for {asset} {tf} are stale (age={data_age:.0f}s), skipping cache")
                            continue
                        
                        # Cache is valid
                        out[tf] = {
                            "candles": candles,
                            "data_age_seconds": data_age
                        }
                await session.commit()
        except Exception:
            out = out or {}

    # 3. Backfill still-missing timeframes via async provider waterfall
    missing = [tf for tf in tfs if tf not in out]
    if missing:
        rest: dict = {}
        try:
            rest_timeout = max(
                1.0,
                float(os.getenv("MARKET_TIMEFRAME_FETCH_TIMEOUT_SECONDS", "15") or 15),
            )
        except Exception:
            rest_timeout = 15.0

        async def _fetch_one(tf: str):
            try:
                candles = await asyncio.wait_for(
                    async_get_candles(asset, tf),
                    timeout=rest_timeout,
                )
                if candles:
                    provider = _get_last_provider_used(asset, tf)
                    return tf, {
                        "candles": candles,
                        "source": provider or "provider_fallback_chain",
                    }
            except asyncio.TimeoutError:
                logger.warning(f"[market_data] provider waterfall timeout for {asset} {tf}")
            except Exception as e:
                logger.warning(f"[market_data] provider waterfall failed for {asset} {tf}: {e}")
            return tf, {}

        fetched = await asyncio.gather(*[_fetch_one(tf) for tf in missing], return_exceptions=False)
        rest = {tf: payload for tf, payload in fetched if payload}
        
        # Validate and add data_age_seconds for REST data
        for tf, payload in (rest or {}).items():
            candles = (payload or {}).get("candles") or []
            if candles:
                candles = _sanitize_ohlcv(candles)
                payload["candles"] = candles
            
            # Validate OHLCV for REST candles
            if candles and not _validate_ohlcv(candles):
                logger.warning(f"REST candles for {asset} {tf} failed OHLCV validation, skipping")
                continue
            
            # Calculate data age for REST candles (note: REST data is freshly fetched,
            # so we don't reject it for staleness, only report age for monitoring)
            if candles:
                _, data_age = _check_staleness(candles, tf)
                if "data_age_seconds" not in payload:
                    payload["data_age_seconds"] = data_age
            
            # Never replace an already accepted live/cache payload with a
            # later fallback result.
            out.setdefault(tf, payload)

            # Attach lightweight alternative-market signals once per asset, not once
            # for every timeframe returned by the provider waterfall.
            if tf != next(iter(rest), None) or not _env_bool("MARKET_ALTERNATIVE_SIGNALS_ENABLED", True):
                continue
            try:
                async def _fetch_alt():
                    try:
                        sym = str(asset or "").upper().strip()
                        macro: dict = {}
                        # Only attempt for crypto perpetual-like symbols ending with USDT
                        if sym.endswith("USDT"):
                            bid_vol = ask_vol = 0.0
                            try:
                                from engine.derivatives import default_squeeze_detector
                                from engine.microstructure import default_order_book_analyzer

                                funding_rate = await default_squeeze_detector.get_funding_rate(sym)
                                if funding_rate is not None:
                                    macro["funding_rate"] = float(funding_rate)

                                async with httpx.AsyncClient(timeout=3.0) as client:
                                    oi_response = await client.get(
                                        "https://api.bybit.com/v5/market/open-interest",
                                        params={
                                            "category": "linear",
                                            "symbol": sym,
                                            "intervalTime": "5min",
                                            "limit": 1,
                                        },
                                    )
                                if oi_response.status_code == 200:
                                    oi_rows = (oi_response.json().get("result") or {}).get("list") or []
                                    current_oi = float(oi_rows[0].get("openInterest") or 0.0) if oi_rows else 0.0
                                    prev_raw = state.get_sync(f"market:open_interest:{sym}")
                                    prev = float(prev_raw) if prev_raw is not None else None
                                    macro["open_interest_change"] = (
                                        (current_oi - prev) / prev if prev and prev > 0 else 0.0
                                    )
                                    state.set_sync(f"market:open_interest:{sym}", str(current_oi))

                                order_book = await default_order_book_analyzer.fetch_order_book(sym)
                                if order_book:
                                    bids = order_book.get("bids") or []
                                    asks = order_book.get("asks") or []
                                    bid_vol = sum(float(level[1]) for level in bids[:5]) if bids else 0.0
                                    ask_vol = sum(float(level[1]) for level in asks[:5]) if asks else 0.0
                                    total_volume = bid_vol + ask_vol
                                    macro["orderbook_imbalance"] = (
                                        (bid_vol - ask_vol) / total_volume if total_volume > 0 else 0.0
                                    )
                            except Exception:
                                pass
                        # Default zeros for non-crypto or failures
                        macro.setdefault("funding_rate", 0.0)
                        macro.setdefault("open_interest_change", 0.0)
                        macro.setdefault("orderbook_imbalance", 0.0)
                        macro.setdefault("news_sentiment", 0.0)
                        return macro
                    except Exception:
                        return {"funding_rate": 0.0, "open_interest_change": 0.0, "orderbook_imbalance": 0.0, "news_sentiment": 0.0}

                try:
                    enrichment_timeout = max(
                        0.5,
                        float(os.getenv("MARKET_ENRICHMENT_TIMEOUT_SECONDS", "3") or 3),
                    )
                except Exception:
                    enrichment_timeout = 3.0
                macro = await asyncio.wait_for(_fetch_alt(), timeout=enrichment_timeout)
                try:
                    onchain = await asyncio.wait_for(
                        fetch_onchain_context(sym),
                        timeout=enrichment_timeout,
                    )
                    if isinstance(onchain, dict):
                        macro.update(onchain)
                except Exception:
                    pass
                # Attach macro into each timeframe payload for ML helpers to consume
                for tf, payload in list(out.items()):
                    if not isinstance(payload, dict):
                        continue
                    payload.setdefault("_macro", {})
                    # Merge top-level macro fields without overwriting existing keys
                    for k, v in macro.items():
                        payload["_macro"].setdefault(k, v)
                # Also expose a root-level _macro so callers that pass the whole
                # market_data mapping (e.g. engine.core.extract_features) can read it.
                try:
                    out.setdefault("_macro", {})
                    for k, v in macro.items():
                        out["_macro"].setdefault(k, v)
                except Exception:
                    pass
            except Exception:
                pass

            # Best-effort write-through into Postgres cache tables.
        # Per-candle Postgres writes can take longer than the engine's asset
        # deadline and cause asyncio cancellation to discard valid exchange
        # data. The websocket/cache ingestor remains the primary persistence
        # path; opt in only when write latency is known to be safely bounded.
        if _env_bool("MARKET_CACHE_WRITE_THROUGH", False):
            try:
                from datetime import datetime
                from db.market_cache import upsert_market_candle, upsert_market_tick

                def _ts_to_ms(v):
                    if v is None:
                        return None
                    if isinstance(v, (int, float)):
                        # Heuristic: < 10^12 likely seconds.
                        n = int(v)
                        return n * 1000 if n < 1_000_000_000_000 else n
                    s = str(v).strip()
                    if not s:
                        return None
                    try:
                        # AlphaVantage returns ISO without timezone; treat as UTC.
                        dt = datetime.fromisoformat(s.replace("Z", ""))
                        return int(dt.timestamp() * 1000)
                    except Exception:
                        return None

                async with get_session() as session:
                    last_tick_ms = None
                    last_tick_price = None
                    for tf, payload in (rest or {}).items():
                        candles = (payload or {}).get("candles") or []
                        for c in candles:
                            try:
                                ts_ms = _ts_to_ms(c.get("timestamp"))
                                if ts_ms is None:
                                    continue
                                await upsert_market_candle(
                                    session,
                                    symbol=str(asset),
                                    timeframe=str(tf),
                                    open_time_ms=int(ts_ms),
                                    open=float(c.get("open")),
                                    high=float(c.get("high")),
                                    low=float(c.get("low")),
                                    close=float(c.get("close")),
                                    volume=float(c.get("volume") or 0.0),
                                    is_final=True,
                                )
                                last_tick_ms = int(ts_ms)
                                last_tick_price = float(c.get("close"))
                            except Exception:
                                continue
                    if last_tick_price is not None:
                        try:
                            await upsert_market_tick(
                                session,
                                symbol=str(asset),
                                price=float(last_tick_price),
                                event_time_ms=int(last_tick_ms) if last_tick_ms is not None else None,
                            )
                        except Exception:
                            pass
                    await session.commit()
            except Exception:
                pass

    # 4. Crypto cache fallback. This runs only after OKX/Bybit/etc. have had
    # the first chance, and stale cache rows are never accepted.
    missing_after_rest = [tf for tf in tfs if tf not in out]
    if use_cache and is_crypto_asset and missing_after_rest:
        try:
            async with get_session() as session:
                for tf in missing_after_rest:
                    candles = await get_recent_candles(session, symbol=asset, timeframe=tf, limit=limit)
                    if not candles or len(candles) < want:
                        continue
                    candles = _sanitize_ohlcv(candles)
                    if not _validate_ohlcv(candles):
                        continue
                    is_fresh, data_age = _check_staleness(candles, tf)
                    if not is_fresh:
                        logger.warning(
                            "Cached candles for %s %s are stale (age=%.0fs), skipping cache",
                            asset, tf, data_age,
                        )
                        continue
                    out.setdefault(tf, {
                        "candles": candles,
                        "source": "postgres_cache",
                        "data_age_seconds": data_age,
                    })
                await session.commit()
        except Exception:
            pass

    # If cache returned candles without indicators, compute them using existing fetcher pipeline:
    # easiest: re-run calculate_indicators for cached candles.
    try:
        from data.indicators import calculate_indicators

        for tf in list(out.keys()):
            payload = out.get(tf) or {}
            if "indicators" not in payload:
                candles = payload.get("candles") or []
                if candles:
                    payload["indicators"] = calculate_indicators(candles)
                    out[tf] = payload
    except Exception:
        pass

    # TradingView enrichment (indicator-only overlay).
    try:
        for tf in list(out.keys()):
            payload = out.get(tf) or {}
            candles = payload.get("candles") or []
            if not candles:
                continue
            tv_ind = await _tradingview_indicators(asset, tf)
            if tv_ind:
                ind = payload.get("indicators") or {}
                for k, v in tv_ind.items():
                    ind[f"tv_{k}"] = v
                payload["indicators"] = ind
                payload["tradingview_enriched"] = True
                out[tf] = payload
    except Exception:
        pass

    diagnostics = market_data_diagnostics(asset, tfs, out)
    logger.info(
        "[market_data][asset_result] asset=%s asset_class=%s required=%s optional=%s "
        "provider_by_timeframe=%s usable=%s final_reason=%s rejected=%s minimum=%s",
        asset,
        diagnostics["asset_class"],
        diagnostics["required_timeframes"],
        diagnostics["optional_timeframes"],
        diagnostics["provider_by_timeframe"],
        diagnostics["usable"],
        diagnostics["final_reason"],
        diagnostics["rejected_timeframes"],
        diagnostics["minimum_candles"],
    )
    return out
