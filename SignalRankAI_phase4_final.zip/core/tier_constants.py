"""Compatibility constants for delivery and risk controls.

Tier entitlements, quotas, scores, depths, ranks, and features are projected
from :mod:`core.tier_policy`. The historical notes below describe legacy
behavior only; runtime tier decisions must use the canonical policy adapter.

CANONICAL TIER & DELIVERY MODEL (2026-04-12):

Tier Quality Tiers (Score-based):
  - FREE: 60+ (broad access)
  - PREMIUM: 80+ (higher quality standard)
  - VIP: 80+ (highest quality standard)
  - ADMIN: 0+ (all signals for monitoring)
  - OWNER: 0+ (unlimited, receives everything)

Daily Limits (PER DELIVERED SIGNALS to user):
  - FREE: 3 signals/day (hard cap)
  - PREMIUM: 10 signals/day (hard cap, resets at user's local midnight)
  - VIP: 20 signals/day (quality-based soft cap, pauses after 20)
  - OWNER: unlimited

Signal Depth (TP Levels Shown):
  - FREE: TP1, TP2, SL (TP2 is their 'max')
  - PREMIUM: TP1, TP2, SL (same depth as FREE)
  - VIP: TP1, TP2, TP3, SL (full ladder, TP3 is their 'max')
  - OWNER: All TP levels + all outcomes

Delivery Model:
  - Engine generates signals in cycles
  - Signals are RANDOMLY SAMPLED to eligible users per tier
  - Random sampling is PURE (users can permanently miss some signals)
  - Daily limits enforce DELIVERED signals (not eligible signals)
  - Upgrade backfill: only signals already sampled to user (no re-delivery of missed ones)
  - Outcome tracking is strict per (user, signal) pair

Outcome Rules:
  - Once TP is hit on a signal, no SL outcome can be recorded
  - TP progression shows as \"1/3\", \"2/3\", \"3/3\"
  - SL outcome only recorded if no TP was hit
  - Trailing SL: track outcomes against CURRENT SL, not original SL

NEW PRODUCTION UPGRADES (2024):
  - EXPECTANCY_MIN=0.15 (live block below this)
  - DD_SOFT_THROTTLE=0.06, DD_HARD=0.12
  - CANDLE_STALENESS_MULTIPLIER=1.5 (stricter freshness)
"""

import os as _os
from typing import Final

from core.tier_policy import (
    TIER_ORDER as _POLICY_TIER_ORDER,
    get_entitlements as _get_policy_entitlements,
    normalize_tier as _normalize_policy_tier,
    tier_rank as _policy_tier_rank,
)


def _env_int_limit(name: str, default: int) -> int:
    try:
        return max(0, int(float(_os.getenv(name, str(default)) or default)))
    except Exception:
        return int(default)


# Tier daily signal limits (DELIVERED signals per user)
TIER_DAILY_LIMITS: Final[dict[str, float]] = {
    tier.value.lower(): float(_get_policy_entitlements(tier).daily_signal_limit)
    for tier in _POLICY_TIER_ORDER
}

# Tier quality score thresholds (minimum signal score to be eligible)
TIER_SCORE_THRESHOLDS: Final[dict[str, float]] = {
    tier.value.lower(): float(_get_policy_entitlements(tier).minimum_signal_score)
    for tier in _POLICY_TIER_ORDER
}

# Signal depth per tier (how many TP levels shown)
TIER_SIGNAL_DEPTH: Final[dict[str, dict]] = {
    "free": {
        "max_tp_level": 1,
        "show_tp3": False,
        "show_sl": False,
        "detail_level": "basic",  # Limited details, with upgrade prompt
    },
    "premium": {
        "max_tp_level": 2,  # Shows TP1, TP2
        "show_tp3": False,
        "show_sl": True,
        "detail_level": "full",
    },
    "vip": {
        "max_tp_level": 3,  # Shows TP1, TP2, TP3
        "show_tp3": True,
        "show_sl": True,
        "detail_level": "full",
    },
    "owner": {
        "max_tp_level": 3,
        "show_tp3": True,
        "show_sl": True,
        "detail_level": "full",
    },
    "admin": {
        "max_tp_level": 3,
        "show_tp3": True,
        "show_sl": True,
        "detail_level": "full",
    },
}

# Tier upgrade prompt frequency (for FREE users)
UPGRADE_PROMPT_FREQUENCY: Final[str] = "smart"  # Show on strategic signals to maximize conversion
UPGRADE_PROMPT_FREQUENCY_INT: Final[int] = 3  # Every 3rd signal, or based on signal quality

# Signal freshness: max age in seconds before signal is considered stale.
# Keep this strict and centralized as the single source for freshness policy.
MAX_SIGNAL_AGE_SECONDS: Final[dict[str, int]] = {
    "crypto":    300,    # 5 min
  "fx":        300,    # 5 min
  "stock":     300,    # 5 min
  "commodity": 300,    # 5 min
}

# Price drift tolerance: max fractional deviation from entry price (not %).
# These mirror the % values in engine/stale_signal_validator._CLASS_THRESHOLDS.
PRICE_DRIFT_TOLERANCE: Final[dict[str, float]] = {
    "crypto":    0.020,  # 2.0 % — volatile 24/7 market; full cycle can take 30-120 s
    "fx":        0.003,  # 0.3 % — tight spreads; FX moves slowly relative to crypto
    "stock":     0.010,  # 1.0 % — intraday moves justify 1 % tolerance
    "commodity": 0.008,  # 0.8 % — between FX and stock volatility
}

# Candle staleness multiplier: max age = timeframe * this value
# For Railway Hobby tier, use 24x to allow signals even if data is hours behind
_is_railway = bool((_os.getenv("RAILWAY_SERVICE_NAME") or "").strip() or (_os.getenv("RAILWAY_ENVIRONMENT") or "").strip())
CANDLE_STALENESS_MULTIPLIER: Final[float] = float(_os.getenv("CANDLE_STALENESS_MULTIPLIER", "24.0" if _is_railway else "1.5"))

# NEW PRODUCTION RISK CONSTANTS
EXPECTANCY_MIN: Final[float] = 0.15  # Block signals from assets/strategies with expectancy < 0.15
DD_SOFT_THROTTLE: Final[float] = 0.06  # Throttle signals at 6% drawdown
DD_HARD_LIMIT: Final[float] = 0.12  # Hard stop at 12% drawdown

# News sentiment threshold for conflict detection
STRONG_SENTIMENT_THRESHOLD: Final[int] = 2

# Active signal monitoring
ACTIVE_SIGNAL_LOOKBACK_HOURS: Final[int] = 24

# FREE tier specific constants
FREE_MIN_SCORE: Final[int] = 80  # Minimum signal score for FREE tier eligibility (upgraded from 60)
FREE_SIGNAL_DAILY_LIMIT: Final[int] = _env_int_limit("FREE_SIGNAL_DAILY_LIMIT", 3)  # Daily signal limit for FREE users
FREE_PROOF_FEED_LIMIT: Final[int] = 5  # Max signals shown in FREE proof feed


TIER_RANK: Final[dict[str, int]] = {
    tier.value.lower(): _policy_tier_rank(tier)
    for tier in _POLICY_TIER_ORDER
}

TIER_MIN_SCORES: Final[dict[str, float]] = TIER_SCORE_THRESHOLDS


TIER_FEATURES: Final[dict[str, set[str]]] = {
    tier.value.lower(): set(_get_policy_entitlements(tier).features)
    for tier in _POLICY_TIER_ORDER
}

TIER_PRICES_NGN: Final[dict[str, int]] = {
    "premium": int(_os.getenv("PREMIUM_PRICE_NGN", "5000") or 5000),
    "vip": int(_os.getenv("VIP_PRICE_NGN", "15000") or 15000),
}

TIER_PRICES_USD: Final[dict[str, float]] = {
    "premium": float(_os.getenv("PREMIUM_PRICE_USD", "10.0") or 10.0),
    "vip": float(_os.getenv("VIP_PRICE_USD", "30.0") or 30.0),
}

TIER_BILLING_PERIODS: Final[dict[str, str]] = {
    "premium": "monthly",
    "vip": "monthly",
}

TIER_DISPLAY_NAMES: Final[dict[str, str]] = {
    "free": "Free",
    "premium": "Premium",
    "vip": "VIP",
    "admin": "Admin",
    "owner": "Owner",
}

TIER_EMOJIS: Final[dict[str, str]] = {
    "free": "",
    "premium": "",
    "vip": "",
    "admin": "",
    "owner": "",
}

TIER_ASSET_COOLDOWN_HOURS: Final[dict[str, int]] = {
    "free": int(_os.getenv("FREE_ASSET_COOLDOWN_HOURS", "12") or 12),
    "premium": int(_os.getenv("PREMIUM_ASSET_COOLDOWN_HOURS", "12") or 12),
    "vip": int(_os.getenv("VIP_ASSET_COOLDOWN_HOURS", "12") or 12),
    "admin": int(_os.getenv("ADMIN_ASSET_COOLDOWN_HOURS", "12") or 12),
    "owner": int(_os.getenv("OWNER_ASSET_COOLDOWN_HOURS", "12") or 12),
}

VIP_MAX_CAPACITY: Final[int] = int(_os.getenv("VIP_MAX_CAPACITY", "30") or 30)


def tier_rank(tier: str) -> int:
    """Return numeric rank for tier comparison; higher means more access."""
    return _policy_tier_rank(tier)


def normalize_tier(tier: str | None) -> str:
    """Normalize tier labels to canonical lowercase keys."""
    return _normalize_policy_tier(tier).value.lower()


def has_feature(tier: str, feature: str) -> bool:
    """Return whether a tier has a named feature flag."""
    features = TIER_FEATURES.get(normalize_tier(tier), TIER_FEATURES["free"])
    return "*" in features or str(feature or "").strip() in features


def get_daily_limit(tier: str) -> float:
    """Return the daily delivered-signal limit for a tier."""
    return TIER_DAILY_LIMITS.get(normalize_tier(tier), TIER_DAILY_LIMITS["free"])


def get_min_score(tier: str) -> float:
    """Return the minimum delivery score for a tier."""
    return TIER_SCORE_THRESHOLDS.get(normalize_tier(tier), TIER_SCORE_THRESHOLDS["free"])

